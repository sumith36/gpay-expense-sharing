"""Generate a realistic (and deliberately messy) sample dataset.

Creates three CSV files in this folder:
  members.csv   - group members and their income weight
  expenses.csv  - expenses and refunds (with some dirty rows on purpose)
  payments.csv  - settle-up payments (completed / missed / pending)

Run:  python data/generate_data.py
"""
from __future__ import annotations

import os
import random

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
rng = random.Random(42)

MEMBERS = [
    # group,        user,     income_weight
    ("Flat4B",      "Arjun",  50),
    ("Flat4B",      "Priya",  40),
    ("Flat4B",      "Karthik", 30),
    ("Flat4B",      "Meera",  30),
    ("GoaTrip",     "Arjun",  50),
    ("GoaTrip",     "Divya",  35),
    ("GoaTrip",     "Rahul",  35),
    ("GoaTrip",     "Sneha",  20),
    ("GoaTrip",     "Vikram", 40),
]

FLAT = ["Arjun", "Priya", "Karthik", "Meera"]
TRIP = ["Arjun", "Divya", "Rahul", "Sneha", "Vikram"]
rows = []
_id = 0


def add(date, group, category, desc, amount, paid_by, split_type, participants="",
        details="", kind="expense", refund_of=""):
    global _id
    _id += 1
    rows.append(dict(expense_id=f"E{_id:03d}", date=date, group_id=group, category=category,
                     description=desc, amount=amount, paid_by=paid_by, split_type=split_type,
                     participants=participants, split_details=details, type=kind,
                     refund_of=refund_of))
    return f"E{_id:03d}"


flat_all = "|".join(FLAT)
trip_all = "|".join(TRIP)

# ---------------- Flat4B: Jul - Oct 2026 (recurring household costs) ----------------
for m, month in enumerate(["2026-07", "2026-08", "2026-09", "2026-10"]):
    # Rent: paid unevenly by two people, split by income  (UNEVEN CONTRIBUTIONS + WEIGHTED)
    add(f"{month}-01", "Flat4B", "Rent", "Monthly rent", 36000, "Arjun:20000|Priya:16000",
        "income", flat_all)
    add(f"{month}-05", "Flat4B", "Utilities", "Electricity bill", rng.randint(1800, 3200),
        rng.choice(FLAT), "equal", flat_all)
    add(f"{month}-07", "Flat4B", "Utilities", "Wi-Fi", 1180, "Karthik", "equal", flat_all)
    for d in (4, 11, 18, 25):
        add(f"{month}-{d:02d}", "Flat4B", "Groceries", "Weekly groceries",
            rng.randint(900, 2400), rng.choice(FLAT), "equal", flat_all)
    for d in rng.sample(range(2, 28), 3):
        who = rng.choice(FLAT)
        guests = rng.sample([u for u in FLAT if u != who], 2)
        add(f"{month}-{d:02d}", "Flat4B", "Food Delivery", "Dinner order", rng.randint(500, 1500),
            who, "equal", "|".join([who] + guests))

# Meera is vegetarian-only groceries: she is excluded from the meat order (PARTIAL PARTICIPATION)
add("2026-08-14", "Flat4B", "Groceries", "Chicken & eggs", 1450, "Priya", "equal",
    "Arjun|Priya|Karthik")
# Custom weights: AC used mostly in Arjun's room
ac = add("2026-09-10", "Flat4B", "Utilities", "AC servicing", 2400, "Arjun", "weighted", "",
    "Arjun:3|Priya:1|Karthik:1|Meera:1")
# Exact amounts
add("2026-09-20", "Flat4B", "Household", "Kitchen shelf + hooks", 1300, "Meera", "exact", "",
    "Arjun:400|Priya:300|Karthik:300|Meera:300")
# Refund (partial) of the AC service: company refunded Rs 600
add("2026-09-22", "Flat4B", "Utilities", "AC servicing - partial refund", 600, "Arjun",
    "equal", "", kind="refund", refund_of=ac)

# ---------------- GoaTrip: Aug 2026 ----------------
add("2026-08-20", "GoaTrip", "Travel", "Flights", 31500, "Vikram", "exact", "",
    "Arjun:6300|Divya:6300|Rahul:6300|Sneha:6300|Vikram:6300")
add("2026-08-21", "GoaTrip", "Stay", "Beach villa (3 nights)", 27000, "Arjun:15000|Divya:12000",
    "income", trip_all)
add("2026-08-21", "GoaTrip", "Transport", "Scooter rental", 3000, "Rahul", "percent", "",
    "Arjun:25|Divya:25|Rahul:25|Vikram:25")           # Sneha does not ride
add("2026-08-22", "GoaTrip", "Food", "Beach shack lunch", 4350, "Divya", "equal", trip_all)
add("2026-08-22", "GoaTrip", "Food", "Seafood dinner", 7800, "Sneha", "equal", trip_all)
add("2026-08-23", "GoaTrip", "Activities", "Water sports", 9000, "Vikram", "equal",
    "Arjun|Rahul|Vikram|Divya")
add("2026-08-23", "GoaTrip", "Food", "Cafe + drinks", 3260, "Arjun", "equal", trip_all)
add("2026-08-24", "GoaTrip", "Transport", "Airport cab", 2200, "Rahul", "equal", trip_all)
vid = add("2026-08-24", "GoaTrip", "Activities", "Sunset cruise", 6000, "Divya", "equal", trip_all)
add("2026-08-26", "GoaTrip", "Activities", "Sunset cruise - cancelled for 2 people", 2400, "Divya",
    "equal", "", kind="refund", refund_of=vid)

# ---------------- Deliberately dirty rows (to demonstrate preprocessing) ----------------
dirty = [
    # exact duplicate (same expense_id)
    dict(rows[5]),
    # missing amount
    dict(expense_id="E901", date="2026-08-30", group_id="Flat4B", category="Groceries",
         description="Vegetables", amount="", paid_by="priya", split_type="equal",
         participants=flat_all, split_details="", type="expense", refund_of=""),
    # inconsistent casing / spaces in names, missing category
    dict(expense_id="E902", date="2026-09-03", group_id="Flat4B", category="",
         description="Cooking gas", amount="1050", paid_by="  meera ", split_type="EQUAL",
         participants="arjun|PRIYA|Karthik|meera", split_details="", type="expense", refund_of=""),
    # unknown user
    dict(expense_id="E903", date="2026-09-04", group_id="Flat4B", category="Food Delivery",
         description="Party pizza", amount="1800", paid_by="Arjun", split_type="equal",
         participants="Arjun|Priya|Zorro", split_details="", type="expense", refund_of=""),
    # contributions do not add up to the bill
    dict(expense_id="E904", date="2026-09-08", group_id="Flat4B", category="Utilities",
         description="Water tanker", amount="1000", paid_by="Arjun:600|Priya:300", split_type="equal",
         participants=flat_all, split_details="", type="expense", refund_of=""),
    # percentages that do not sum to 100
    dict(expense_id="E905", date="2026-09-12", group_id="Flat4B", category="Household",
         description="Curtains", amount="2000", paid_by="Karthik", split_type="percent",
         participants="", split_details="Arjun:40|Priya:40|Karthik:30", type="expense", refund_of=""),
    # invalid date
    dict(expense_id="E906", date="31-31-2026", group_id="Flat4B", category="Groceries",
         description="Milk", amount="300", paid_by="Meera", split_type="equal",
         participants=flat_all, split_details="", type="expense", refund_of=""),
    # refund bigger than the original expense
    dict(expense_id="E907", date="2026-09-25", group_id="Flat4B", category="Utilities",
         description="Over-refund", amount="9000", paid_by="Arjun", split_type="equal",
         participants="", split_details="", type="refund", refund_of=ac),
    # refund of an expense that does not exist
    dict(expense_id="E908", date="2026-09-26", group_id="Flat4B", category="Utilities",
         description="Refund of ghost expense", amount="200", paid_by="Arjun", split_type="equal",
         participants="", split_details="", type="refund", refund_of="E999"),
    # negative amount
    dict(expense_id="E909", date="2026-09-27", group_id="GoaTrip", category="Food",
         description="Typo entry", amount="-500", paid_by="Divya", split_type="equal",
         participants=trip_all, split_details="", type="expense", refund_of=""),
]
rows.extend(dirty)

exp = pd.DataFrame(rows)
exp = exp.sample(frac=1, random_state=7).sort_values(["date", "expense_id"], kind="stable")

# ---------------- Settle-up payments ----------------
payments = [
    # payment_id, due/pay date, group, from, to, amount, status
    ("P001", "2026-08-31", "Flat4B", "Karthik", "Arjun", 4000, "completed"),
    ("P002", "2026-09-15", "Flat4B", "Meera", "Priya", 3000, "completed"),
    ("P003", "2026-09-30", "Flat4B", "Karthik", "Priya", 2500, "missed"),
    ("P004", "2026-10-05", "Flat4B", "Meera", "Arjun", 2000, "pending"),
    ("P005", "2026-08-28", "GoaTrip", "Sneha", "Vikram", 5000, "completed"),
    ("P006", "2026-09-10", "GoaTrip", "Rahul", "Arjun", 3000, "missed"),
    ("P007", "2026-09-20", "GoaTrip", "Sneha", "Divya", 1500, "missed"),
    ("P008", "2026-10-02", "GoaTrip", "Rahul", "Divya", 2000, "completed"),
]
pay = pd.DataFrame(payments, columns=["payment_id", "date", "group_id", "from_user", "to_user",
                                      "amount", "status"])

mem = pd.DataFrame(MEMBERS, columns=["group_id", "user", "income_weight"])

if __name__ == "__main__":
    mem.to_csv(os.path.join(HERE, "members.csv"), index=False)
    exp.to_csv(os.path.join(HERE, "expenses.csv"), index=False)
    pay.to_csv(os.path.join(HERE, "payments.csv"), index=False)
    print(f"members.csv  : {len(mem)} rows")
    print(f"expenses.csv : {len(exp)} rows (incl. {len(dirty)} deliberately dirty)")
    print(f"payments.csv : {len(pay)} rows")
