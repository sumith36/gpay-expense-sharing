"""Run the whole pipeline:  python main.py  [--data-dir data] [--out-dir outputs] [--as-of YYYY-MM-DD]

load -> clean -> ledger -> balances -> fairness checks -> settlement plan
     -> analytics -> charts -> CSV/JSON outputs + console report
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys

import pandas as pd

from expense_share import analytics, fairness, visualize
from expense_share.ledger import build_ledger, compute_balances
from expense_share.money import fmt
from expense_share.preprocessing import load_and_clean

pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 30)


def rupees(df: pd.DataFrame) -> pd.DataFrame:
    """Add readable rupee columns next to every *_p (paise) column."""
    out = df.copy()
    for c in [c for c in df.columns if c.endswith("_p")]:
        out[c[:-2] + "_rs"] = (out[c] / 100).round(2)
    return out


def banner(text: str) -> None:
    print("\n" + "=" * 78 + f"\n{text}\n" + "=" * 78)


def main() -> None:
    ap = argparse.ArgumentParser(description="Google Pay-inspired expense sharing system")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--out-dir", default="outputs")
    ap.add_argument("--as-of", default=None, help="reference date for overdue calculation")
    args = ap.parse_args()

    if not os.path.exists(os.path.join(args.data_dir, "expenses.csv")):
        print("No data found - generating the sample dataset first ...")
        subprocess.run([sys.executable, os.path.join(args.data_dir, "generate_data.py")], check=True)

    charts = os.path.join(args.out_dir, "charts")
    os.makedirs(charts, exist_ok=True)

    # 1) load + clean --------------------------------------------------------------
    clean = load_and_clean(args.data_dir)
    # 2) ledger (also rejects invalid splits/refunds, logging each one) ---------------
    ledger = build_ledger(clean)
    # 3) balances ---------------------------------------------------------------------
    bal = compute_balances(ledger, clean).merge(clean.members, on=["group_id", "user"])
    as_of = pd.Timestamp(args.as_of) if args.as_of else max(clean.expenses["date"].max(),
                                                           clean.payments["date"].max())

    groups = sorted(bal["group_id"].unique())
    reliability = {g: analytics.payment_reliability(clean.payments, list(bal[bal.group_id == g].user), g)
                   for g in groups}
    plan = analytics.settlement_plans(bal, reliability)
    overdue = analytics.overdue_report(clean.payments, as_of)

    # ---------------------------------------------------------------- console report
    banner("1. DATA QUALITY")
    issues = pd.DataFrame(clean.issues)
    print(f"expenses read: {clean.raw_counts['expenses']}   accepted: {len(ledger.expenses)}   "
          f"payments read: {clean.raw_counts['payments']}   accepted: {len(clean.payments)}")
    print(f"issues logged: {len(issues)}\n")
    print(issues.to_string(index=False))

    summary = dict(as_of=str(as_of.date()), data_quality=dict(
        expenses_read=clean.raw_counts["expenses"], expenses_accepted=int(len(ledger.expenses)),
        issues=int(len(issues))), groups={})
    fairness_all, scenario_all = [], []

    for g in groups:
        gb = bal[bal.group_id == g].reset_index(drop=True)
        users = list(gb["user"])
        gplan = plan[plan.group_id == g]
        net_send = {}
        for t in gplan.itertuples():
            net_send[t.from_user] = net_send.get(t.from_user, 0) + t.amount_p
            net_send[t.to_user] = net_send.get(t.to_user, 0) - t.amount_p
        ft = fairness.fairness_table(gb, net_send)
        income = dict(zip(gb["user"], gb["income_weight"]))
        scn = fairness.scenario_comparison(ledger.lines, income, g)
        fairness_all.append(ft.assign(group_id=g)); scenario_all.append(scn.assign(group_id=g))

        meta = ledger.expenses
        cat = analytics.category_spend(meta, g)
        monthly = analytics.monthly_spend(meta, g)
        fc = analytics.forecast_next_month(monthly)
        pair = analytics.pairwise_matrix(ledger.lines, g, users)
        naive_n = analytics.naive_transaction_count(pair)
        j_before = fairness.jain_index(ft["contribution_ratio"])
        total = int(meta[meta.group_id == g]["signed_amount_p"].sum())

        banner(f"2. GROUP: {g}   (total net spend {fmt(total)}, "
               f"{int((meta.group_id == g).sum())} expenses/refunds)")
        view = gb[["user", "paid_p", "owed_p", "net_expense_p", "sent_p", "received_p", "net_balance_p"]].copy()
        for c in view.columns[1:]:
            view[c] = view[c].map(fmt)
        view.columns = ["user", "paid", "fair share", "net (expenses)", "sent", "received", "net balance"]
        print(view.to_string(index=False))

        print(f"\nSettle-up plan ({len(gplan)} payments; {naive_n} if every pairwise debt were paid separately):")
        for t in gplan.itertuples():
            warn = "   <-- low reliability" if t.debtor_reliability < 0.5 else ""
            print(f"   {t.from_user:<8} pays {t.to_user:<8} {fmt(t.amount_p):>14}   "
                  f"(payer reliability {t.debtor_reliability:.2f}){warn}")
        print(f"\nFairness: Jain index before settling = {j_before:.3f}  ->  after plan = "
              f"{'1.000' if (ft['residual_after_plan_p'] == 0).all() else 'NOT BALANCED'}   "
              f"(max residual {fmt(int(ft['residual_after_plan_p'].abs().max()))})")
        print("Top categories: " + ", ".join(f"{r.category} {r.share_pct:.0f}%" for r in cat.head(3).itertuples()))
        print(f"Next-month forecast: Rs {fc['forecast']:,.0f}  [{fc['method']}]")

        # charts
        visualize.paid_vs_owed(gb, g, charts)
        visualize.net_balances(gb, g, charts)
        visualize.category_breakdown(cat, g, charts)
        visualize.monthly_trend(monthly, fc, g, charts)
        visualize.cumulative(analytics.cumulative_spend(meta, g), g, charts)
        visualize.pairwise_heatmap(pair, g, charts)
        visualize.settlement_graph(users, gplan, g, charts)
        visualize.policy_comparison(scn, g, charts)
        visualize.reliability_chart(reliability[g], g, charts)

        summary["groups"][g] = dict(
            total_spend_rs=total / 100, payments_in_plan=int(len(gplan)), naive_payments=naive_n,
            jain_before=round(j_before, 4), jain_after=1.0 if (ft["residual_after_plan_p"] == 0).all() else None,
            forecast_next_month_rs=round(fc["forecast"], 2), forecast_method=fc["method"],
            top_category=cat.iloc[0]["category"])

    banner("3. MISSED / OVERDUE PAYMENTS (these do NOT reduce anyone's balance)")
    o = overdue.copy(); o["amount"] = o["amount_p"].map(fmt); o["due_date"] = o["due_date"].dt.date
    print(o.drop(columns="amount_p").to_string(index=False))
    banner("4. PAYMENT RELIABILITY (smoothed score)")
    print(pd.concat(reliability.values()).assign(group=lambda d: sum(([g] * len(reliability[g]) for g in groups), []))
          .round(2).to_string(index=False))
    banner("5. POLICY WHAT-IF: total share under alternative split policies (Rs)")
    sc = pd.concat(scenario_all)
    print(sc.assign(**{c: (sc[c] / 100).round(0) for c in ["actual_rule_p", "pure_equal_p", "pure_income_p"]})
          [["group_id", "user", "pure_equal_p", "actual_rule_p", "pure_income_p"]]
          .rename(columns=lambda c: c.replace("_p", "")).to_string(index=False))

    # ---------------------------------------------------------------- files
    rupees(ledger.lines).to_csv(os.path.join(args.out_dir, "ledger_lines.csv"), index=False)
    rupees(bal).to_csv(os.path.join(args.out_dir, "balances.csv"), index=False)
    rupees(plan).to_csv(os.path.join(args.out_dir, "settlement_plan.csv"), index=False)
    rupees(overdue).to_csv(os.path.join(args.out_dir, "overdue_payments.csv"), index=False)
    issues.to_csv(os.path.join(args.out_dir, "data_quality_report.csv"), index=False)
    pd.concat(fairness_all).to_csv(os.path.join(args.out_dir, "fairness_table.csv"), index=False)
    rupees(sc).to_csv(os.path.join(args.out_dir, "policy_comparison.csv"), index=False)
    with open(os.path.join(args.out_dir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nDone. Files and {len(os.listdir(charts))} charts written to '{args.out_dir}/'.")


if __name__ == "__main__":
    main()
