"""Unit tests.  Run with:  python -m unittest discover -s tests -v"""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from expense_share.ledger import build_ledger, compute_balances          # noqa: E402
from expense_share.money import allocate, to_paise                       # noqa: E402
from expense_share.preprocessing import load_and_clean                   # noqa: E402
from expense_share.settlement import min_cash_flow                       # noqa: E402
from expense_share.splitter import SplitError, compute_owed, compute_paid  # noqa: E402

HEADER = "expense_id,date,group_id,category,description,amount,paid_by,split_type,participants,split_details,type,refund_of\n"


def make_clean(expense_rows, payment_rows=""):
    d = tempfile.mkdtemp()
    files = {"members.csv": "group_id,user,income_weight\nG,A,60\nG,B,30\nG,C,10\n",
             "expenses.csv": HEADER + expense_rows,
             "payments.csv": "payment_id,date,group_id,from_user,to_user,amount,status\n" + payment_rows}
    for name, text in files.items():
        with open(os.path.join(d, name), "w") as fh:
            fh.write(text)
    return load_and_clean(d)


class TestMoney(unittest.TestCase):
    def test_allocate_sums_exactly(self):
        for total in (1, 100, 1000, 9999, 100001):
            for w in ({"a": 1, "b": 1, "c": 1}, {"a": 3, "b": 1, "c": 1}, {"a": 0.333, "b": 0.667}):
                self.assertEqual(sum(allocate(total, w).values()), total)

    def test_penny_goes_to_largest_remainder(self):
        self.assertEqual(sorted(allocate(100, {"a": 1, "b": 1, "c": 1}).values()), [33, 33, 34])

    def test_to_paise(self):
        self.assertEqual(to_paise("12.345"), 1235)
        self.assertEqual(to_paise(100), 10000)


class TestSplitter(unittest.TestCase):
    def test_equal(self):
        self.assertEqual(compute_owed("equal", 30000, "A|B|C", "", {}), {"A": 10000, "B": 10000, "C": 10000})

    def test_weighted_and_income(self):
        self.assertEqual(compute_owed("weighted", 30000, "", "A:2|B:1", {}), {"A": 20000, "B": 10000})
        self.assertEqual(compute_owed("income", 10000, "A|B", "", {"A": 60, "B": 40}), {"A": 6000, "B": 4000})

    def test_bad_percent_and_exact(self):
        with self.assertRaises(SplitError):
            compute_owed("percent", 1000, "", "A:50|B:40", {})
        with self.assertRaises(SplitError):
            compute_owed("exact", 1000, "", "A:5|B:4", {})

    def test_uneven_contributions(self):
        self.assertEqual(compute_paid("A:7|B:3", 1000), {"A": 700, "B": 300})
        with self.assertRaises(SplitError):
            compute_paid("A:7|B:2", 1000)


class TestLedger(unittest.TestCase):
    def test_simple_balances(self):
        c = make_clean("E1,2026-01-01,G,Food,Dinner,300,A,equal,A|B|C,,expense,\n")
        b = compute_balances(build_ledger(c), c).set_index("user")
        self.assertEqual(b.loc["A", "net_balance_p"], 20000)
        self.assertEqual(b.loc["B", "net_balance_p"], -10000)
        self.assertEqual(int(b["net_balance_p"].sum()), 0)

    def test_refund_reverses_pro_rata(self):
        c = make_clean("E1,2026-01-01,G,Food,Dinner,300,A,equal,A|B|C,,expense,\n"
                       "E2,2026-01-02,G,Food,Refund,150,,equal,,,refund,E1\n")
        b = compute_balances(build_ledger(c), c).set_index("user")
        self.assertEqual(b.loc["A", "net_balance_p"], 10000)       # was 20000, half refunded
        self.assertEqual(b.loc["B", "net_balance_p"], -5000)

    def test_refund_larger_than_original_rejected(self):
        c = make_clean("E1,2026-01-01,G,Food,Dinner,300,A,equal,A|B|C,,expense,\n"
                       "E2,2026-01-02,G,Food,Refund,400,A,equal,,,refund,E1\n")
        self.assertEqual(len(build_ledger(c).expenses), 1)
        self.assertTrue(any("exceeds" in i["issue"] for i in c.issues))

    def test_missed_and_pending_payments_do_not_move_money(self):
        c = make_clean("E1,2026-01-01,G,Food,Dinner,300,A,equal,A|B|C,,expense,\n",
                       "P1,2026-01-05,G,B,A,100,missed\nP2,2026-01-06,G,C,A,100,pending\n")
        b = compute_balances(build_ledger(c), c).set_index("user")
        self.assertEqual(b.loc["B", "net_balance_p"], -10000)       # still owes
        self.assertEqual(b.loc["B", "missed_p"], 10000)

    def test_completed_payment_reduces_debt(self):
        c = make_clean("E1,2026-01-01,G,Food,Dinner,300,A,equal,A|B|C,,expense,\n",
                       "P1,2026-01-05,G,B,A,100,completed\n")
        b = compute_balances(build_ledger(c), c).set_index("user")
        self.assertEqual(b.loc["B", "net_balance_p"], 0)
        self.assertEqual(b.loc["A", "net_balance_p"], 10000)

    def test_dirty_rows_are_logged_not_silently_dropped(self):
        c = make_clean("E1,2026-01-01,G,Food,Dinner,300,A,equal,A|B|C,,expense,\n"
                       "E1,2026-01-01,G,Food,Dinner,300,A,equal,A|B|C,,expense,\n"      # duplicate
                       "E3,2026-01-01,G,Food,Oops,,A,equal,A|B,,expense,\n"             # no amount
                       "E4,2026-01-01,G,Food,Ghost,50,A,equal,A|Zed,,expense,\n")       # unknown user
        self.assertEqual(len(build_ledger(c).expenses), 1)
        self.assertEqual(len(c.issues), 3)

    def test_name_normalisation(self):
        c = make_clean("E1,2026-01-01,G,Food,Dinner,300,  a ,EQUAL,a|b|C,,expense,\n")
        self.assertEqual(len(build_ledger(c).expenses), 1)


class TestSettlement(unittest.TestCase):
    def test_transfers_clear_all_balances(self):
        bal = {"A": 5000, "B": -2000, "C": -1000, "D": -2500, "E": 500}
        net = dict(bal)
        for d, c, amt in min_cash_flow(bal):
            net[d] += amt
            net[c] -= amt
        self.assertTrue(all(v == 0 for v in net.values()))

    def test_at_most_n_minus_1_transfers(self):
        bal = {"A": 5000, "B": -2000, "C": -1000, "D": -2500, "E": 500}
        self.assertLessEqual(len(min_cash_flow(bal)), len(bal) - 1)

    def test_unbalanced_input_rejected(self):
        with self.assertRaises(ValueError):
            min_cash_flow({"A": 100, "B": -50})


if __name__ == "__main__":
    unittest.main()
