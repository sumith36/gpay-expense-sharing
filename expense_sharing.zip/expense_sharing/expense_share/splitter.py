"""Split rules: how one expense is divided among its participants.

Supported split types (column `split_type` in expenses.csv)
-----------------------------------------------------------
equal     everybody in `participants` pays the same
weighted  custom ratios            e.g. "Arjun:2|Priya:1"
percent   percentages (sum = 100)  e.g. "Arjun:70|Priya:30"
exact     exact rupee amounts      e.g. "Arjun:800|Priya:200"
income    proportional to each member's `income_weight` in members.csv
"""
from __future__ import annotations

from typing import Dict, List

from .money import allocate, to_paise


class SplitError(ValueError):
    """Raised when an expense has an invalid or inconsistent split."""


def parse_pairs(text: str) -> Dict[str, float]:
    """Parse 'A:2|B:1' into {'A': 2.0, 'B': 1.0}."""
    out: Dict[str, float] = {}
    for token in str(text).split("|"):
        token = token.strip()
        if not token:
            continue
        if ":" not in token:
            raise SplitError(f"bad token '{token}', expected 'name:value'")
        name, value = token.rsplit(":", 1)
        try:
            out[name.strip()] = float(value)
        except ValueError as exc:
            raise SplitError(f"bad number in '{token}'") from exc
    return out


def parse_users(text: str) -> List[str]:
    """Parse 'A|B|C' into ['A', 'B', 'C']."""
    return [t.strip() for t in str(text).split("|") if t.strip()]


def compute_owed(split_type: str, total: int, participants: str, details: str,
                 income_weights: Dict[str, float]) -> Dict[str, int]:
    """Return {user: paise owed} for one expense. Always sums to `total`."""
    st = str(split_type).strip().lower()

    if st == "equal":
        users = parse_users(participants)
        if not users:
            raise SplitError("equal split needs participants")
        return allocate(total, {u: 1 for u in users})

    if st == "income":
        users = parse_users(participants)
        if not users:
            raise SplitError("income split needs participants")
        missing = [u for u in users if u not in income_weights]
        if missing:
            raise SplitError(f"no income weight for {missing}")
        return allocate(total, {u: income_weights[u] for u in users})

    if st == "weighted":
        weights = parse_pairs(details)
        if not weights:
            raise SplitError("weighted split needs split_details")
        return allocate(total, weights)

    if st == "percent":
        pct = parse_pairs(details)
        if not pct or abs(sum(pct.values()) - 100) > 0.01:
            raise SplitError(f"percentages must sum to 100 (got {sum(pct.values()):.2f})")
        return allocate(total, pct)

    if st == "exact":
        amounts = {u: to_paise(v) for u, v in parse_pairs(details).items()}
        if sum(amounts.values()) != total:
            raise SplitError(
                f"exact amounts add up to {sum(amounts.values())/100:.2f}, expense is {total/100:.2f}")
        return amounts

    raise SplitError(f"unknown split_type '{split_type}'")


def compute_paid(paid_by: str, total: int) -> Dict[str, int]:
    """Who actually paid the bill. 'Arjun' or 'Arjun:600|Priya:400' (uneven contributions)."""
    text = str(paid_by).strip()
    if ":" not in text:
        users = parse_users(text)
        if len(users) != 1:
            raise SplitError("paid_by must be a single user or 'user:amount|user:amount'")
        return {users[0]: total}
    paid = {u: to_paise(v) for u, v in parse_pairs(text).items()}
    if sum(paid.values()) != total:
        raise SplitError(
            f"contributions add up to {sum(paid.values())/100:.2f}, expense is {total/100:.2f}")
    return paid
