"""Analytics: per-user / per-group tracking, trends, reliability, overdue payments."""
from __future__ import annotations

from typing import Dict, List

import numpy as np
import pandas as pd

from .fairness import fairness_table, jain_index
from .money import fmt
from .preprocessing import CleanData
from .settlement import min_cash_flow


# --------------------------------------------------------------------- spending patterns
def category_spend(meta: pd.DataFrame, group: str) -> pd.DataFrame:
    """Net spend per category (refunds already subtracted)."""
    g = meta[meta["group_id"] == group]
    out = g.groupby("category")["signed_amount_p"].sum().sort_values(ascending=False).reset_index()
    out["share_pct"] = 100 * out["signed_amount_p"] / out["signed_amount_p"].sum()
    return out


def monthly_spend(meta: pd.DataFrame, group: str) -> pd.Series:
    g = meta[meta["group_id"] == group].copy()
    g["month"] = g["date"].dt.to_period("M").astype(str)
    return g.groupby("month")["signed_amount_p"].sum() / 100          # rupees


def forecast_next_month(monthly: pd.Series) -> Dict[str, float]:
    """Linear-trend forecast (NumPy least squares). Falls back to the mean if < 3 months."""
    y = monthly.to_numpy(dtype=float)
    if len(y) < 3:
        return dict(forecast=float(y.mean()), slope=0.0, method="mean (history < 3 months)")
    x = np.arange(len(y))
    slope, intercept = np.polyfit(x, y, 1)
    return dict(forecast=max(0.0, float(slope * len(y) + intercept)), slope=float(slope),
                method="linear trend (least squares)")


def cumulative_spend(meta: pd.DataFrame, group: str) -> pd.Series:
    g = meta[meta["group_id"] == group]
    return g.groupby("date")["signed_amount_p"].sum().cumsum() / 100


def pairwise_matrix(lines: pd.DataFrame, group: str, users: List[str]) -> pd.DataFrame:
    """Raw 'who owes whom' (rupees) straight from the expenses, BEFORE simplification.

    For each expense a person's share is attributed to the payers pro-rata to what
    each payer put in. Rows = debtor, columns = creditor.
    """
    m = pd.DataFrame(0.0, index=users, columns=users)
    for _, e in lines[lines["group_id"] == group].groupby("expense_id"):
        paid_total = e["paid_p"].sum()
        for d in e.itertuples():
            if d.owed_p == 0:
                continue
            for c in e.itertuples():
                if c.paid_p != 0 and c.user != d.user:
                    m.loc[d.user, c.user] += d.owed_p * c.paid_p / paid_total / 100
    return m


# ----------------------------------------------------------------- payment behaviour
def payment_reliability(payments: pd.DataFrame, users: List[str], group: str) -> pd.DataFrame:
    """Smoothed on-time score = (completed + 1) / (completed + missed + 2).

    The +1/+2 (Laplace smoothing) stops one missed payment from giving a brand-new
    user a score of 0 and one success from giving a perfect 1. Pending payments are
    ignored until they either complete or are missed.
    """
    p = payments[payments["group_id"] == group]
    rows = []
    for u in users:
        mine = p[p["from_user"] == u]
        c, m, pend = (int((mine["status"] == s).sum()) for s in ("completed", "missed", "pending"))
        rows.append(dict(user=u, completed=c, missed=m, pending=pend,
                         reliability=(c + 1) / (c + m + 2)))
    return pd.DataFrame(rows)


def overdue_report(payments: pd.DataFrame, as_of: pd.Timestamp) -> pd.DataFrame:
    """Missed payments, plus pending ones whose due date has already passed."""
    p = payments[(payments["status"] == "missed") |
                 ((payments["status"] == "pending") & (payments["date"] < as_of))].copy()
    p["days_overdue"] = (as_of - p["date"]).dt.days
    return p[["payment_id", "group_id", "from_user", "to_user", "amount_p", "status",
              "date", "days_overdue"]].rename(columns={"date": "due_date"}).reset_index(drop=True)


# ---------------------------------------------------------------------- settlement plan
def settlement_plans(balances: pd.DataFrame, reliability: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows = []
    for g, grp in balances.groupby("group_id"):
        net = {r.user: int(r.net_balance_p) for r in grp.itertuples()}
        rel = reliability[g].set_index("user")["reliability"]
        for debtor, creditor, amt in min_cash_flow(net):
            rows.append(dict(group_id=g, from_user=debtor, to_user=creditor, amount_p=amt,
                             debtor_reliability=round(float(rel.get(debtor, 1.0)), 2)))
    return pd.DataFrame(rows)


def naive_transaction_count(pairwise: pd.DataFrame) -> int:
    """How many payments would be needed if every pairwise debt were paid separately
    (net of the two directions)."""
    net = pairwise - pairwise.T
    return int((net.to_numpy() > 0.005).sum())
