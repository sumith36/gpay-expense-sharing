"""Charts (Matplotlib). Every function saves a PNG and returns its path."""
from __future__ import annotations

import math
import os
from typing import Dict, List

import matplotlib
matplotlib.use("Agg")                       # headless: no display needed
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

PALETTE = ["#4285F4", "#34A853", "#FBBC05", "#EA4335", "#8E63CE", "#00ACC1"]   # Google-ish colours


def _save(fig, out_dir: str, name: str) -> str:
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, name)
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return path


def paid_vs_owed(bal: pd.DataFrame, group: str, out_dir: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 4))
    x = np.arange(len(bal))
    ax.bar(x - 0.2, bal["paid_p"] / 100, 0.4, label="Paid (out of pocket)", color=PALETTE[0])
    ax.bar(x + 0.2, bal["owed_p"] / 100, 0.4, label="Fair share (owed)", color=PALETTE[2])
    ax.set_xticks(x, bal["user"])
    ax.set_ylabel("Rupees")
    ax.set_title(f"{group}: what each person paid vs. their fair share")
    ax.legend()
    return _save(fig, out_dir, f"{group}_paid_vs_owed.png")


def net_balances(bal: pd.DataFrame, group: str, out_dir: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 4))
    vals = bal["net_balance_p"] / 100
    ax.bar(bal["user"], vals, color=[PALETTE[1] if v >= 0 else PALETTE[3] for v in vals])
    ax.axhline(0, color="black", lw=0.8)
    for i, v in enumerate(vals):
        ax.text(i, v, f"{v:,.0f}", ha="center", va="bottom" if v >= 0 else "top", fontsize=9)
    ax.set_ylabel("Rupees  (+ is owed money, - owes money)")
    ax.set_title(f"{group}: net balance after completed payments")
    return _save(fig, out_dir, f"{group}_net_balances.png")


def category_breakdown(cat: pd.DataFrame, group: str, out_dir: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 4))
    d = cat.sort_values("signed_amount_p")
    ax.barh(d["category"], d["signed_amount_p"] / 100, color=PALETTE[0])
    for i, (v, p) in enumerate(zip(d["signed_amount_p"] / 100, d["share_pct"])):
        ax.text(v, i, f"  {v:,.0f} ({p:.0f}%)", va="center", fontsize=9)
    ax.set_xlim(0, (d["signed_amount_p"].max() / 100) * 1.25)
    ax.set_xlabel("Rupees (net of refunds)")
    ax.set_title(f"{group}: spending by category")
    return _save(fig, out_dir, f"{group}_categories.png")


def monthly_trend(monthly: pd.Series, forecast: Dict[str, float], group: str, out_dir: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(monthly.index, monthly.values, color=PALETTE[0], label="Actual")
    if len(monthly) >= 3:
        nxt_label = (pd.Period(monthly.index[-1]) + 1).strftime("%Y-%m")
        ax.bar([nxt_label], [forecast["forecast"]], color="none", edgecolor=PALETTE[3],
               hatch="//", label=f"Forecast: {forecast['forecast']:,.0f}")
        xs = np.arange(len(monthly) + 1)
        trend = forecast["slope"] * xs + (monthly.mean() - forecast["slope"] * (len(monthly) - 1) / 2)
        ax.plot(list(monthly.index) + [nxt_label], trend, color=PALETTE[3], lw=1.5, ls="--")
    ax.set_ylabel("Rupees")
    ax.set_ylim(0, max(monthly.max(), forecast["forecast"]) * 1.3)
    ax.set_title(f"{group}: monthly spend" + (" + next-month forecast" if len(monthly) >= 3 else ""))
    ax.legend(loc="upper left")
    return _save(fig, out_dir, f"{group}_monthly_trend.png")


def cumulative(series: pd.Series, group: str, out_dir: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.step(series.index, series.values, where="post", color=PALETTE[1], lw=2)
    ax.fill_between(series.index, series.values, step="post", alpha=0.15, color=PALETTE[1])
    ax.set_ylabel("Cumulative rupees")
    ax.set_title(f"{group}: cumulative group spend")
    fig.autofmt_xdate()
    return _save(fig, out_dir, f"{group}_cumulative_spend.png")


def pairwise_heatmap(m: pd.DataFrame, group: str, out_dir: str) -> str:
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(m.values, cmap="Blues")
    ax.set_xticks(range(len(m)), m.columns, rotation=30)
    ax.set_yticks(range(len(m)), m.index)
    for i in range(len(m)):
        for j in range(len(m)):
            if m.values[i, j] > 0.5:
                ax.text(j, i, f"{m.values[i, j]:,.0f}", ha="center", va="center", fontsize=8,
                        color="white" if m.values[i, j] > m.values.max() / 2 else "black")
    ax.set_xlabel("is owed by ... (creditor)")
    ax.set_ylabel("owes ... (debtor)")
    ax.set_title(f"{group}: raw pairwise debts before simplification (Rs)")
    fig.colorbar(im, ax=ax, shrink=0.8)
    return _save(fig, out_dir, f"{group}_pairwise_heatmap.png")


def settlement_graph(users: List[str], transfers: pd.DataFrame, group: str, out_dir: str) -> str:
    fig, ax = plt.subplots(figsize=(6, 6))
    n = len(users)
    pos = {u: (math.cos(2 * math.pi * i / n), math.sin(2 * math.pi * i / n)) for i, u in enumerate(users)}
    for u, (x, y) in pos.items():
        ax.scatter([x], [y], s=1800, color=PALETTE[0], zorder=3)
        ax.text(x, y, u, ha="center", va="center", color="white", fontsize=9, zorder=4)
    for t in transfers.itertuples():
        (x1, y1), (x2, y2) = pos[t.from_user], pos[t.to_user]
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1), zorder=2,
                    arrowprops=dict(arrowstyle="-|>", color=PALETTE[3], lw=1.8, shrinkA=22, shrinkB=22))
        ax.text((x1 + x2) / 2, (y1 + y2) / 2, f"Rs {t.amount_p / 100:,.0f}", fontsize=9,
                ha="center", bbox=dict(boxstyle="round", fc="white", ec="grey", alpha=0.9), zorder=5)
    ax.set_xlim(-1.5, 1.5); ax.set_ylim(-1.5, 1.5); ax.axis("off")
    ax.set_title(f"{group}: simplified settle-up plan ({len(transfers)} payments)")
    return _save(fig, out_dir, f"{group}_settlement_graph.png")


def policy_comparison(scn: pd.DataFrame, group: str, out_dir: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 4))
    x = np.arange(len(scn)); w = 0.27
    for k, (col, label) in enumerate([("pure_equal_p", "Pure equal split"),
                                       ("actual_rule_p", "Rules actually used"),
                                       ("pure_income_p", "Pure income-weighted")]):
        ax.bar(x + (k - 1) * w, scn[col] / 100, w, label=label, color=PALETTE[k])
    ax.set_xticks(x, scn["user"]); ax.set_ylabel("Total share (Rs)")
    ax.set_title(f"{group}: total share under different split policies")
    ax.legend(fontsize=8)
    return _save(fig, out_dir, f"{group}_policy_comparison.png")


def reliability_chart(rel: pd.DataFrame, group: str, out_dir: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 3.6))
    colors = [PALETTE[1] if r >= 0.6 else PALETTE[2] if r >= 0.4 else PALETTE[3] for r in rel["reliability"]]
    ax.bar(rel["user"], rel["reliability"], color=colors)
    ax.set_ylim(0, 1); ax.axhline(0.5, color="grey", ls=":", lw=1)
    for i, r in enumerate(rel.itertuples()):
        ax.text(i, r.reliability + 0.02, f"{r.completed}ok / {r.missed}missed", ha="center", fontsize=8)
    ax.set_ylabel("Payment reliability score")
    ax.set_title(f"{group}: settle-up reliability")
    return _save(fig, out_dir, f"{group}_reliability.png")
