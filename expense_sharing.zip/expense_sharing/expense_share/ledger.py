"""Core accounting: turn cleaned expenses into a per-user ledger and balances.

Sign convention
---------------
For every expense we record, per user, how much they PAID (`paid_p`) and how
much they OWE as their share (`owed_p`). Refunds are stored as *negative*
expenses, so they automatically reverse the original payment and the original
shares. A user's net position is   paid - owed:
    positive  -> the group owes this user money (creditor)
    negative  -> this user owes the group money (debtor)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

import pandas as pd

from .money import allocate
from .preprocessing import CleanData
from .splitter import SplitError, compute_owed, compute_paid


@dataclass
class Ledger:
    lines: pd.DataFrame      # one row per (expense, user): paid_p, owed_p (signed paise)
    expenses: pd.DataFrame   # one row per accepted expense/refund with signed amount


def build_ledger(clean: CleanData) -> Ledger:
    income: Dict[str, Dict[str, float]] = {}
    for r in clean.members.itertuples():
        income.setdefault(r.group_id, {})[r.user] = float(r.income_weight)

    accepted: Dict[str, dict] = {}   # expense_id -> what we need to reverse it later
    lines: List[dict] = []
    meta: List[dict] = []

    for r in clean.expenses.to_dict("records"):
        eid, total, group = r["expense_id"], r["amount_p"], r["group_id"]
        try:
            if r["type"] == "expense":
                paid = compute_paid(r["paid_by"], total)
                owed = compute_owed(r["split_type"], total, r["participants"],
                                    r["split_details"], income[group])
                sign, category = 1, r["category"]
            else:  # ----- refund -----
                orig = accepted.get(r["refund_of"])
                if orig is None or orig["group"] != group:
                    raise SplitError(f"refund_of '{r['refund_of']}' not found in this group")
                if orig["refunded"] + total > orig["total"]:
                    raise SplitError("refund exceeds the original expense "
                                     f"({(orig['refunded'] + total) / 100:.2f} > {orig['total'] / 100:.2f})")
                # Refund is shared exactly the way the original was shared (pro-rata).
                owed = allocate(total, orig["owed"])
                paid = (compute_paid(r["paid_by"], total) if r["paid_by"]
                        else allocate(total, orig["paid"]))
                sign, category = -1, orig["category"]
                orig["refunded"] += total
        except (SplitError, ValueError) as exc:
            clean.log("ledger", eid, str(exc), "row rejected")
            continue

        # Safety net: money paid must equal money owed for every expense.
        assert sum(paid.values()) == sum(owed.values()) == total, eid
        if r["type"] == "expense":
            accepted[eid] = dict(group=group, total=total, owed=owed, paid=paid, refunded=0,
                                 category=r["category"])

        for user in sorted(set(paid) | set(owed)):
            lines.append(dict(expense_id=eid, date=r["date"], group_id=group, category=category,
                              user=user, paid_p=sign * paid.get(user, 0),
                              owed_p=sign * owed.get(user, 0)))
        meta.append(dict(expense_id=eid, date=r["date"], group_id=group, category=category,
                         description=r["description"], type=r["type"], signed_amount_p=sign * total))

    return Ledger(pd.DataFrame(lines), pd.DataFrame(meta))


def compute_balances(ledger: Ledger, clean: CleanData) -> pd.DataFrame:
    """Per-user totals and the net balance after *completed* settle-up payments.

    * completed payments move money and reduce debts
    * pending / missed payments do NOT change balances - they stay owed, and are
      reported separately (see analytics.overdue_report)
    """
    base = clean.members[["group_id", "user"]].copy()
    tot = (ledger.lines.groupby(["group_id", "user"])[["paid_p", "owed_p"]].sum().reset_index())
    bal = base.merge(tot, on=["group_id", "user"], how="left").fillna({"paid_p": 0, "owed_p": 0})
    bal[["paid_p", "owed_p"]] = bal[["paid_p", "owed_p"]].astype("int64")
    bal["net_expense_p"] = bal["paid_p"] - bal["owed_p"]

    done = clean.payments[clean.payments["status"] == "completed"]
    sent = done.groupby(["group_id", "from_user"])["amount_p"].sum().rename("sent_p")
    got = done.groupby(["group_id", "to_user"])["amount_p"].sum().rename("received_p")
    bal = bal.merge(sent, left_on=["group_id", "user"], right_index=True, how="left")
    bal = bal.merge(got, left_on=["group_id", "user"], right_index=True, how="left")
    bal[["sent_p", "received_p"]] = bal[["sent_p", "received_p"]].fillna(0).astype("int64")
    bal["net_balance_p"] = bal["net_expense_p"] + bal["sent_p"] - bal["received_p"]

    for status in ("missed", "pending"):
        sub = clean.payments[clean.payments["status"] == status]
        amt = sub.groupby(["group_id", "from_user"])["amount_p"].sum().rename(f"{status}_p")
        bal = bal.merge(amt, left_on=["group_id", "user"], right_index=True, how="left")
        bal[f"{status}_p"] = bal[f"{status}_p"].fillna(0).astype("int64")

    for g, grp in bal.groupby("group_id"):   # the books of every group must balance exactly
        assert grp["net_expense_p"].sum() == 0 and grp["net_balance_p"].sum() == 0, g
    return bal
