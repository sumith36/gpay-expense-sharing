"""Debt simplification ("settle up") - minimum-transactions algorithm."""
from __future__ import annotations

import heapq
from typing import Dict, List, Tuple

Transfer = Tuple[str, str, int]   # (debtor, creditor, paise)


def min_cash_flow(balances: Dict[str, int]) -> List[Transfer]:
    """Turn net balances into a short list of payments.

    Greedy rule: repeatedly let the person who owes the most pay the person who
    is owed the most. Each transfer fully settles at least one person, so a
    group of n people never needs more than n-1 payments (instead of up to
    n*(n-1)/2 raw pairwise debts). Uses integer paise, so it is exact.
    """
    if sum(balances.values()) != 0:
        raise ValueError("balances must sum to zero")
    creditors = [(-b, u) for u, b in balances.items() if b > 0]   # max-heaps via negation
    debtors = [(b, u) for u, b in balances.items() if b < 0]      # b is negative -> most negative first
    heapq.heapify(creditors)
    heapq.heapify(debtors)

    transfers: List[Transfer] = []
    while creditors and debtors:
        c_amt, creditor = heapq.heappop(creditors)
        d_amt, debtor = heapq.heappop(debtors)
        c_amt, d_amt = -c_amt, -d_amt                 # both positive now
        pay = min(c_amt, d_amt)
        transfers.append((debtor, creditor, pay))
        if c_amt > pay:
            heapq.heappush(creditors, (-(c_amt - pay), creditor))
        if d_amt > pay:
            heapq.heappush(debtors, (-(d_amt - pay), debtor))
    return transfers
