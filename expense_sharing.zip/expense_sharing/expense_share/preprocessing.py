"""Data loading and cleaning.

Every problem found is written to an *issue log* (stage, record id, what was
wrong, what we did about it) so that nothing is silently dropped. The log is
exported as `outputs/data_quality_report.csv`.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

import pandas as pd

from .money import to_paise

EXPENSE_COLS = ["expense_id", "date", "group_id", "category", "description", "amount",
                "paid_by", "split_type", "participants", "split_details", "type", "refund_of"]
PAYMENT_COLS = ["payment_id", "date", "group_id", "from_user", "to_user", "amount", "status"]
VALID_STATUS = {"completed", "missed", "pending"}


@dataclass
class CleanData:
    expenses: pd.DataFrame
    payments: pd.DataFrame
    members: pd.DataFrame
    issues: List[dict] = field(default_factory=list)
    raw_counts: Dict[str, int] = field(default_factory=dict)

    def log(self, stage: str, record_id: str, issue: str, action: str) -> None:
        self.issues.append(dict(stage=stage, record_id=record_id, issue=issue, action=action))


def _read(path: str) -> pd.DataFrame:
    """Read everything as text; blanks stay '' (never NaN) so we control the parsing."""
    return pd.read_csv(path, dtype=str, keep_default_na=False)


def _canonical(text: str, group: str, canon: Dict[Tuple[str, str], str]) -> str:
    """Normalise 'arjun | PRIYA:2' -> 'Arjun|Priya:2'. Raises KeyError on unknown user."""
    pieces = []
    for token in str(text).split("|"):
        token = token.strip()
        if not token:
            continue
        name, sep, value = token.partition(":")
        key = (group, name.strip().lower())
        if key not in canon:
            raise KeyError(name.strip())
        pieces.append(canon[key] + (sep + value.strip() if sep else ""))
    return "|".join(pieces)


def load_and_clean(data_dir: str) -> CleanData:
    members = _read(f"{data_dir}/members.csv")
    expenses = _read(f"{data_dir}/expenses.csv")
    payments = _read(f"{data_dir}/payments.csv")
    result = CleanData(pd.DataFrame(), pd.DataFrame(), pd.DataFrame(),
                       raw_counts=dict(expenses=len(expenses), payments=len(payments),
                                       members=len(members)))

    # ---- members -------------------------------------------------------------------
    members["group_id"] = members["group_id"].str.strip()
    members["user"] = members["user"].str.strip()
    members["income_weight"] = pd.to_numeric(members["income_weight"], errors="coerce")
    bad = members["income_weight"].isna() | (members["income_weight"] <= 0)
    for _, r in members[bad].iterrows():
        result.log("members", f"{r.group_id}/{r.user}", "missing/invalid income weight",
                   "defaulted to the group's median weight")
    for g, grp in members.groupby("group_id"):
        median = grp.loc[~bad[grp.index], "income_weight"].median()
        members.loc[grp.index[bad[grp.index]], "income_weight"] = median if pd.notna(median) else 1
    canon = {(r.group_id, r.user.lower()): r.user for r in members.itertuples()}
    groups = set(members["group_id"])

    # ---- expenses ------------------------------------------------------------------
    expenses = expenses.reindex(columns=EXPENSE_COLS, fill_value="")
    for c in EXPENSE_COLS:
        expenses[c] = expenses[c].astype(str).str.strip()

    dup = expenses.duplicated(subset="expense_id", keep="first")
    for eid in expenses.loc[dup, "expense_id"]:
        result.log("expenses", eid, "duplicate expense_id", "kept first occurrence, dropped copy")
    expenses = expenses[~dup]

    keep = []
    for r in expenses.to_dict("records"):
        eid = r["expense_id"]

        def reject(issue):
            result.log("expenses", eid, issue, "row dropped")

        if r["group_id"] not in groups:
            reject(f"unknown group '{r['group_id']}'"); continue
        date = pd.to_datetime(r["date"], errors="coerce")
        if pd.isna(date):
            reject(f"invalid date '{r['date']}'"); continue
        amount = pd.to_numeric(r["amount"], errors="coerce")
        if pd.isna(amount):
            reject("missing / non-numeric amount"); continue
        if amount <= 0:
            reject(f"non-positive amount {amount}"); continue
        etype = (r["type"] or "expense").lower()
        if etype not in {"expense", "refund"}:
            reject(f"unknown type '{r['type']}'"); continue
        try:
            for col in ("paid_by", "participants", "split_details"):
                r[col] = _canonical(r[col], r["group_id"], canon)
        except KeyError as exc:
            reject(f"unknown user {exc}"); continue
        if not r["category"]:
            result.log("expenses", eid, "missing category", "set to 'Uncategorized'")
            r["category"] = "Uncategorized"
        r.update(date=date, amount_p=to_paise(amount), type=etype,
                 split_type=(r["split_type"] or "equal").lower())
        keep.append(r)

    exp_cols = [c for c in EXPENSE_COLS if c != "amount"] + ["amount_p"]
    result.expenses = (pd.DataFrame(keep, columns=exp_cols)
                       .astype({"amount_p": "int64", "date": "datetime64[ns]"})
                       .sort_values(["date", "expense_id"], kind="stable").reset_index(drop=True))

    # ---- payments (settle-up transfers) ----------------------------------------------
    payments = payments.reindex(columns=PAYMENT_COLS, fill_value="")
    for c in PAYMENT_COLS:
        payments[c] = payments[c].astype(str).str.strip()
    dup = payments.duplicated(subset="payment_id", keep="first")
    for pid in payments.loc[dup, "payment_id"]:
        result.log("payments", pid, "duplicate payment_id", "dropped copy")
    payments = payments[~dup]

    keep = []
    for r in payments.to_dict("records"):
        pid = r["payment_id"]
        date = pd.to_datetime(r["date"], errors="coerce")
        amount = pd.to_numeric(r["amount"], errors="coerce")
        status = r["status"].lower()
        problem = None
        if r["group_id"] not in groups:
            problem = "unknown group"
        elif pd.isna(date):
            problem = "invalid date"
        elif pd.isna(amount) or amount <= 0:
            problem = "missing / non-positive amount"
        elif status not in VALID_STATUS:
            problem = f"unknown status '{r['status']}'"
        elif r["from_user"].lower() == r["to_user"].lower():
            problem = "payer and receiver are the same person"
        else:
            try:
                r["from_user"] = _canonical(r["from_user"], r["group_id"], canon)
                r["to_user"] = _canonical(r["to_user"], r["group_id"], canon)
            except KeyError as exc:
                problem = f"unknown user {exc}"
        if problem:
            result.log("payments", pid, problem, "row dropped")
            continue
        r.update(date=date, amount_p=to_paise(amount), status=status)
        keep.append(r)

    pay_cols = [c for c in PAYMENT_COLS if c != "amount"] + ["amount_p"]
    result.payments = (pd.DataFrame(keep, columns=pay_cols)
                       .astype({"amount_p": "int64", "date": "datetime64[ns]"})
                       .sort_values(["date", "payment_id"], kind="stable").reset_index(drop=True))
    result.members = members.reset_index(drop=True)
    return result
