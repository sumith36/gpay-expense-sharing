"""Money helpers.

All money is stored as *integer paise* (1 INR = 100 paise). Floating point is
never used for balances, so the books always balance to the exact paisa.
"""
from __future__ import annotations

import math
from decimal import Decimal, ROUND_HALF_UP
from fractions import Fraction
from typing import Dict, Mapping


def to_paise(amount) -> int:
    """Convert a rupee amount (str/float/int) to integer paise."""
    return int((Decimal(str(amount)) * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def fmt(paise: int) -> str:
    """Format paise as a readable rupee string, e.g. 'Rs 1,250.50'."""
    sign = "-" if paise < 0 else ""
    return f"{sign}Rs {abs(paise) / 100:,.2f}"


def allocate(total: int, weights: Mapping[str, float]) -> Dict[str, int]:
    """Split `total` paise among users in proportion to `weights`.

    Uses the *largest remainder method*: every user first gets the floor of
    their exact share, then the leftover paise are handed out one by one to the
    users with the largest fractional remainders (ties broken by input order,
    so the result is deterministic). The returned shares always sum to
    exactly `total`.
    """
    if total < 0:
        raise ValueError("allocate() expects a non-negative total")
    if not weights:
        raise ValueError("no users to allocate to")
    exact = {u: Fraction(str(w)) for u, w in weights.items()}
    if any(w < 0 for w in exact.values()):
        raise ValueError("weights must be non-negative")
    weight_sum = sum(exact.values())
    if weight_sum <= 0:
        raise ValueError("weights must sum to a positive number")

    raw = {u: Fraction(total) * w / weight_sum for u, w in exact.items()}
    base = {u: math.floor(r) for u, r in raw.items()}
    leftover = total - sum(base.values())
    names = list(raw)
    order = sorted(names, key=lambda u: (-(raw[u] - base[u]), names.index(u)))
    for u in order[:leftover]:
        base[u] += 1
    return base
