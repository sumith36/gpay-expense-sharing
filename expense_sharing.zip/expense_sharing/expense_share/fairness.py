"""Fairness logic and diagnostics.

What "fair" means here
----------------------
1. Each expense is divided by an explicit, auditable rule (equal / weighted /
   percent / exact / income-proportional) among the people who actually took
   part in it - nobody is charged for things they did not use.
2. After settling, every person's *net contribution equals their share*:
        paid_i + (transfers sent) - (transfers received) = owed_i
3. The books balance to the exact paisa (sum of all balances = 0).
4. Uneven contributions are not a problem: whoever paid more is simply a
   creditor, whoever paid less is a debtor.

Jain's fairness index measures how evenly "contribution / fair share" is spread:
J = (sum x)^2 / (n * sum x^2), where x_i = contribution_i / share_i.
J = 1 means everybody contributed exactly their fair share.
"""
from __future__ import annotations

from typing import Dict, Iterable

import pandas as pd

from .money import allocate
from .preprocessing import CleanData


def jain_index(values: Iterable[float]) -> float:
    x = [v for v in values if v == v]          # drop NaN
    if not x or sum(v * v for v in x) == 0:
        return 1.0
    return float(sum(x) ** 2 / (len(x) * sum(v * v for v in x)))


def fairness_table(balances: pd.DataFrame, transfers: Dict[str, int] | None = None) -> pd.DataFrame:
    """Per-user fairness view for ONE group's balance table.

    `transfers` optionally maps user -> net paise they will send (+) / receive (-)
    under the settlement plan, used to prove everybody ends up at exactly 0.
    """
    t = balances.copy()
    total_owed = t["owed_p"].sum()
    t["burden_share"] = t["owed_p"] / total_owed if total_owed else 0.0
    t["income_share"] = t["income_weight"] / t["income_weight"].sum()
    t["equity_gap"] = t["burden_share"] - t["income_share"]        # >0: carries more than income share
    eff_paid = t["paid_p"] + t["sent_p"] - t["received_p"]         # contribution incl. settle-ups so far
    t["contribution_ratio"] = (eff_paid / t["owed_p"]).where(t["owed_p"] > 0)
    if transfers is not None:
        after = t["net_balance_p"] + t["user"].map(transfers).fillna(0)
        t["residual_after_plan_p"] = after.astype("int64")
    return t


def scenario_comparison(lines: pd.DataFrame, income: Dict[str, float], group: str) -> pd.DataFrame:
    """What would each person have paid under alternative policies?

    Re-splits every expense of the group (same participants) under three policies:
    the rule actually used, a pure equal split, and a pure income-proportional split.
    """
    g = lines[lines["group_id"] == group]
    actual = g.groupby("user")["owed_p"].sum()
    equal, weighted = {}, {}
    for _, e in g.groupby("expense_id"):
        e = e[e["owed_p"] != 0]
        signed_total = int(e["owed_p"].sum())
        sign, total = (1 if signed_total >= 0 else -1), abs(signed_total)
        users = list(e["user"])
        for scheme, store in ((lambda u: 1, equal), (lambda u: income[u], weighted)):
            for u, v in allocate(total, {u: scheme(u) for u in users}).items():
                store[u] = store.get(u, 0) + sign * v
    out = pd.DataFrame({"actual_rule_p": actual, "pure_equal_p": pd.Series(equal),
                        "pure_income_p": pd.Series(weighted)}).fillna(0).astype("int64")
    out.index.name = "user"
    return out.reset_index()
