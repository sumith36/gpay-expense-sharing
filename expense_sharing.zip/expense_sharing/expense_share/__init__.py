"""Expense Sharing System (Google Pay-inspired) - data science mini project."""
__version__ = "1.0.0"
